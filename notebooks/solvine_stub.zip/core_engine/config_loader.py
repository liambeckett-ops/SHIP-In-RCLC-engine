"""
core_engine.config_loader
Loads YAML and .env configuration files. Handles active config profiles.
"""

import os
import yaml

class ConfigLoader:
    def __init__(self, config_dir="config", env_mode=None):
        self.config_dir = config_dir
        self.env_mode = env_mode or os.getenv("ENV_MODE", "base")
        self.config = self.load_config()

    def load_config(self):
        config_path = os.path.join(self.config_dir, f"{self.env_mode}.yaml")
        try:
            with open(config_path, "r") as file:
                return yaml.safe_load(file)
        except FileNotFoundError:
            print(f"[CONFIG] Warning: {config_path} not found. Using defaults.")
            return {}
